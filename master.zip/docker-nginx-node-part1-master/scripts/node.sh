#!/usr/bin/env bash

docker run -d --name nodejs -p 5000:5000 example/nodejs 
